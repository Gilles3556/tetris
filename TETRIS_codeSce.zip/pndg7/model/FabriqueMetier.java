package pndg7.model;

import pndg7.ihm.ConstantesIhm;

public final class FabriqueMetier {
    private FabriqueMetier(){}

    public static ShapeCurrent creerShapeCurrent(){
        return new ShapeCurrent();
    }

    public static Ensemble creerEnsemble() {
        return new Ensemble(ConstantesIhm.BOARD_WIDTH * ConstantesIhm.BOARD_HEIGHT);
    }
        public static JeuTetris creerJeu( Ensemble ens){
            return new JeuTetris(ens);
    }

    public static FacadeJeuTetris creerFacadeJeuTetris( Ensemble ens ) {
        return new FacadeJeuTetris(ens);
    }
}
