package pndg7.model;

public enum TypeEtatsDuJeu {
    ARRET,DEMARRE,PAUSE;
}
