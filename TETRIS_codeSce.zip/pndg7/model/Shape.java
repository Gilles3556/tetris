package pndg7.model;

import pndg7.ihm.ConstantesIhm;
import pndg7.ihm.OutilsGui;

public class Shape {

    private Tetrominoe forme; // la forme de la pièce
    private int coords[][];  // coordonnées des quatre carrés constituant la piece
    private int noRotation;

    public int[][] getCoords() {
        return coords;
    }

    public void setCoords( int[][] coords ) {
        this.coords = coords;
    }

    public void setForme( Tetrominoe t ) {
        forme = t;
    }

    public Tetrominoe getForme() {
        return forme;
    }

    public Shape() {
        initShape();
    }

    private void initShape() {
        coords = new int[4][2];
        noRotation = 0;
        setForme(Tetrominoe.NoShape);

    }

    public void setX( int index, int x ) {
        coords[index][ConstantesIhm.IDX_X] = x;
    }

    public void setY( int index, int y ) {
        coords[index][ConstantesIhm.IDX_Y] = y;
    }

    public int x( int index ) {
        return coords[index][ConstantesIhm.IDX_X];
    }

    public int y( int index ) {
        return coords[index][ConstantesIhm.IDX_Y];
    }

    public void rotate() {
        if (this.getForme() != Tetrominoe.SquareShape) {
            noRotation++;

            //System.out.println("---rotate(): noRotation="+noRotation);
            int[][] tabloRotation = null;

            switch (this.getForme().ordinal()) {
                case 1:
                case 2:
                case 3:
                    tabloRotation = OutilsGui.calculerRotation(this.getForme(),noRotation);
                     // MAJ du noRotation
                    if(noRotation==1) {
                        noRotation = -1;
                    }
                    break;
                case 4:
                case 6:
                case 7:
                    tabloRotation = OutilsGui.calculerRotation(this.getForme(), noRotation);
                    //MAJ du noRotation
                    if (noRotation == 3) {
                        noRotation = -1;
                    }
                    break;
            }

            this.setCoords(tabloRotation);
            //System.out.println("\nnoRotation="+noRotation);
            //System.out.println(this);
        }
    }

    public void rotateLeft() {
        if (this.getForme() != Tetrominoe.SquareShape) {

            int[][] tablow = new int[ConstantesIhm.MAX_POINT][ConstantesIhm.MAX_COORD];
            for (int i = 0; i < 4; ++i) {
                tablow[i][0] = -x(i);
                tablow[i][1] = y(i);
            }
            //MAJ des coordonnées des carrés constituant la forme
            this.setCoords(tablow);
        }
    }

    public void rotateRight() {
        if (this.getForme() != Tetrominoe.SquareShape) {

            int[][] tablow = new int[4][2];
            for (int i = 0; i < 4; ++i) {
                tablow[i][0] = x(i);
                tablow[i][1] = -y(i);
            }
            //MAJ des coordonnées des carrés constituant la forme
            this.setCoords(tablow);
        }
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Shape{");
        sb.append("pieceShape=").append(forme);
        sb.append(", \ncoords=");
        if (coords == null) {
            sb.append(" null");
        } else {

            //Arrays.asList(coords).toString());
            for (int i = 0; i < coords.length; i++) {
                sb.append("\n carré nO:" + (i + 1) + " !! ");
                for (int y = 0; y < coords[i].length; y++) {
                    int c = coords[i][y];
                    sb.append((c >= 0 ? " " : "") + c + " ! ");
                }
            }
        }
        //sb.append(", coordsTable=").append(coordsTable == null ? "null" : Arrays.asList(coordsTable).toString());
        /*sb.append(", \ncoordsTable=");
        for(int i=0;i<coordsTable.length;i++){
            sb.append("\n");
            for(int y=0;y<coordsTable[i].length;y++){
                sb.append("( ");
                for(int z=0;z<coordsTable[i][y].length;z++){
                    sb.append(String.format("%02d",coordsTable[i][y][z])).append(' ');
                }
                sb.append(" )");
            }
        }*/
        sb.append('}');
        return sb.toString();
    }
}

