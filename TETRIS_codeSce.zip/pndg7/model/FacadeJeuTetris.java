package pndg7.model;

import java.lang.reflect.Type;

public class FacadeJeuTetris {
    private JeuTetris leJeu;

    public FacadeJeuTetris(Ensemble ens){
        leJeu = new JeuTetris(ens);
    }

    private JeuTetris getLeJeu() {
        return leJeu;
    }
    public TypeEtatsDuJeu getEtatDuJeu(){
        return leJeu.getEtat();
    }

    public void clearLesPieces() {
        leJeu.clearLesPieces();
    }

    public void mettreLeJeuEnPause() {
        leJeu.pauser();
    }

    public Tetrominoe getFormeAt( int j, int i ) {
        return leJeu.getFormeAt(j,i);
    }

    public Ensemble getLesPieces() {
        return leJeu.getLesPieces();
    }

    public void demarrerLeJeu() {
        leJeu.demarrer();
    }

    public void arreterLeJeu() {
        leJeu.arreter();
    }

    public boolean isJeuPaused() {
            return leJeu.getEtat()== TypeEtatsDuJeu.PAUSE;
    }
}
