package pndg7.model;

import pndg7.ihm.ConstantesIhm;

public class Ensemble {
    private Tetrominoe[] tablo;

    public Ensemble(int dim){
        tablo = new Tetrominoe[dim];
    }

    public void clear(){
        for(int i=0;i< tablo.length;i++){
            tablo[i] = Tetrominoe.NoShape;
        }
    }

    public Tetrominoe getFormeAt( int x, int y)  {
       // System.out.println(String.format("shapeAt() [y=%02d: x=%02d",y,x));

        return tablo[(y * ConstantesIhm.BOARD_WIDTH) + x];
    }
    public void setFormeAt( int x, int y, Tetrominoe aTetro){
        tablo[(y * ConstantesIhm.BOARD_WIDTH) + x] = aTetro;
    }
}
