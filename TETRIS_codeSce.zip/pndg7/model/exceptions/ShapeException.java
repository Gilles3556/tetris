package pndg7.model.exceptions;

public class ShapeException extends Exception {
    public ShapeException( String msg) {
        super(msg);
    }
}
