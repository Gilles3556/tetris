package pndg7.model;

import java.awt.*;

public class ShapeCurrent extends Shape {

    private boolean fallingFinished;
    private Point ptCourant;

    public void setPtCourant( Point ptCourant ) {
        this.ptCourant = ptCourant;
    }
    public Point getPtCourant() {
        return ptCourant;
    }

    public ShapeCurrent(){
        super();
        ptCourant = new Point();
        fallingFinished = false;
    }

    public boolean isFallingFinished() {
        return fallingFinished;
    }

    public void setFallingFinished( boolean fallingFinished ) {
        this.fallingFinished = fallingFinished;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ShapeCurrent{");
        sb.append(super.toString());
        sb.append(", \ncurCoords= en [").append(ptCourant.y).append(":").append(ptCourant.x).append("]");
        sb.append(", \n isFallingFinished=").append(fallingFinished);

        sb.append('}');
        return sb.toString();
    }
}


