package pndg7.model;

public class JeuTetris {
    private TypeEtatsDuJeu etat;
    private Ensemble lesPieces;

    public JeuTetris( Ensemble e ) {
        this.etat = TypeEtatsDuJeu.ARRET;
        this.lesPieces = e;
    }

    public void demarrer() {
        this.etat = TypeEtatsDuJeu.DEMARRE;
    }

    public void pauser() {
        if (etat == TypeEtatsDuJeu.DEMARRE) {
            etat = TypeEtatsDuJeu.PAUSE;
        } else {
            etat = TypeEtatsDuJeu.DEMARRE;
        }
        System.out.println("--JeuTetris.pauser(), etat=" + etat.name());
    }

    public void arreter() {
        etat = TypeEtatsDuJeu.ARRET;
    }

    public Ensemble getLesPieces() {
        return lesPieces;
    }

    public void clearLesPieces() {
        lesPieces.clear();
    }

    public Tetrominoe getFormeAt( int j, int i ) {
        return lesPieces.getFormeAt(j, i);
    }

    public TypeEtatsDuJeu getEtat() {
        return etat;
    }
}
