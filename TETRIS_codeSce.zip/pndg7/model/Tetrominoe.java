package pndg7.model;

public enum Tetrominoe {
    NoShape, ZShape, SShape, LineShape,
            TShape, SquareShape, LShape, MirroredLShape, NEW1, NEW1RG;

}
