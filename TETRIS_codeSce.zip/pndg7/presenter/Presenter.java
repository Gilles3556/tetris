package pndg7.presenter;

import pndg7.ihm.FabriqueIhm;
import pndg7.ihm.FenetreTetris;
import pndg7.model.Ensemble;
import pndg7.model.FabriqueMetier;
import pndg7.model.FacadeJeuTetris;
import pndg7.model.JeuTetris;

import java.awt.*;

public class Presenter {
    //IHM
    private FenetreTetris fen;
    //MODEL
    private FacadeJeuTetris facadeJeu;

    public Presenter( Ensemble ens){
       //unJeu= FabriqueMetier.creerJeu(ens);
       facadeJeu = FabriqueMetier.creerFacadeJeuTetris(ens);
       fen = FabriqueIhm.creerFenetreTetris(this);

    }

    public FacadeJeuTetris getFacadeJeu() {
        return facadeJeu;
    }

    public void start(){
        EventQueue.invokeLater(() -> {
            fen.setVisible(true);
        });
    }
}
