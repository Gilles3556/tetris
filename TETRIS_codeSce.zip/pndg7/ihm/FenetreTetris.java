package pndg7.ihm;

import pndg7.model.FacadeJeuTetris;
import pndg7.model.JeuTetris;
import pndg7.presenter.Presenter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*
Java Tetris game clone

Author: Jan Bodnar
Website: http://zetcode.com
 */
public class FenetreTetris extends JFrame implements ActionListener {
    private Board leBoard;
    private JLabel statusbar;
    private JMenuBar barreDeMenu;

    JLabel getStatusBar() {
        return statusbar;
    }

    public FenetreTetris( Presenter p ) {
        initUI(p);
    }

    private void initUI( Presenter p ) {
        //MEP de la barre de MENU
        barreDeMenu = FabriqueIhm.creerBarreDeMenu(this);
        add(barreDeMenu,BorderLayout.NORTH);

        statusbar = new JLabel("Score = 0");
        add(statusbar, BorderLayout.SOUTH);

        leBoard = FabriqueIhm.creerBoard(this,p);
        add(leBoard);
        leBoard.start();

        // ----------MAJ fenêtre
        setTitle(ConstantesIhm.TITRE_JEU);
        setSize(ConstantesIhm.WIDTH_DFLT, ConstantesIhm.HEIGTH_DFLT);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }


    @Override
    public void actionPerformed( ActionEvent e ) {
        String action =e.getActionCommand();
        if(action.equals(ConstantesIhm.MENU_ITEM_DEMARRER)){
            leBoard.demarrerLeJeu();
        }

        if(action.equals(ConstantesIhm.MENU_ITEM_PAUSER)|| action.equals(ConstantesIhm.MENU_ITEM_DEPAUSER)){
            leBoard.pauserLeJeu();
            //MAJ libellé ds le menu
            JMenuItem jmiPause = barreDeMenu.getMenu(0).getItem(1);
            if(leBoard.isJeuPaused()){
                //changer
                jmiPause.setText(ConstantesIhm.MENU_ITEM_DEPAUSER);
            }else{
                jmiPause.setText(ConstantesIhm.MENU_ITEM_PAUSER);
            }
        }

        if(action.equals(ConstantesIhm.MENU_ITEM_QUITTER)) {
            leBoard.arreterJeu();
        }

    }
}
