package pndg7.ihm;

import java.awt.*;
import java.awt.event.KeyEvent;

public final class ConstantesIhm {
    public static final int WIDTH_DFLT = 200;
    public static final int HEIGTH_DFLT = 400 ;

    public static final String TITRE_JEU = ">>MyTetris";

    public final static int BOARD_WIDTH = 10;
    public final static int BOARD_HEIGHT = 22;
    public final static int PERIOD_INTERVAL = 300;

    public static final String MSG_ERR_UNE_COORD_NEGATIVE = " ERR: une coordonnée est négative !";

/*
            D'après les valeurs de l'enum Tetrominoe
            NoShape, ZShape, SShape, LineShape,
            TShape, SquareShape, LShape, MirroredLShape;
            les coordonnées ont exprimées en [X,Y]

    public final static int[][][] TABLEAU_COORDS_FORMES0  = {
        { { 0, 0 },   { 0, 0 },   { 0, 0 },   { 0, 0 } },   // 0: NOSHAPE
        { { 0, -1 },  { 0, 0 },   { -1, 0 },  { -1, 1 } },  // 1:ZShape
        { { 0, -1 },  { 0, 0 },   { 1, 0 },   { -1, -1 } }, // 2:SShape
        { { 0, -1 },  { 0, 0 },   { 0, 1 },   { 0, 2 } },   // 3:LineShape      X
        { { -1, 0 },  { 0, 0 },   { 1, 0 },   { 0, 1 } },   // 4:TSHape         X
        { { 0, 0 },   { 1, 0 },   { 0, 1 },   { 1, 1 } },   // 5:SquareShape    X
        { { -1, -1 }, { 0, -1 },  { 0, 0 },   { 0, 1 } },   // 6:LShape         X
        { { 1, -1 },  { 0, -1 },  { 0, 0 },   { 0, 1 } },   // 7:MirroredLShape X
        {  { -1 , 0 }, { 0 , 0 },{ 1 , 0 },{ 0 , 1 } } ,  //NEW1
        {   {   0, -1}, { 0 , 0 }, { 0 , 1 }, {-1 , 0 }}  //NEW1RG
    };
*/

    public final static int[][][] TABLEAU_COORDS_FORMES  = {
            { { 0, 0}, { 0, 0 }, { 0, 0}, { 0, 0} }, // 0: NOSHAPE
            { { 0, 1}, { 0, 0 }, { 1, 0}, { 1,-1 }}, // 1:ZShape
            { { 0, 0}, { 1, 0 }, {-1, 1}, { 0, 1} }, // 2:SShape
            { {-1, 0}, { 0, 0 }, { 1, 0}, { 2, 0} }, // 3:LineShape      X
            { {-1, 0}, { 0, 0 }, { 1, 0}, { 0, 1} }, // 4:TSHape         X
            { { 0, 0}, { 1, 0 }, { 0, 1}, { 1, 1} }, // 5:SquareShape    X
            { { 0,-1}, { 0, 0 }, { 0, 1}, { 1, 1 }}, // 6:LShape         X
            { { 0,-1}, { 0, 0 }, { 0, 1}, {-1, 1} }, // 7:MirroredLShape X
            { } ,  //NEW1
            { }  //NEW1RG
    };
    /* -------------------------
       Les rotations des formes:
       ------------------------- */
    public final static int[][] ZSHAPE_R1={{-1,-1}, { 0,-1}, { 0, 0}, { 1, 0}}; //1
    public final static int[][] SSHAPE_R1={{0,-1}, { 0, 0}, { 1, 0}, { 1, 1}};   //2
    public final static int[][] LINESHAPE_R1={{ 0, 1},  { 0, 0}, { 0,-1}, { 0,-2}}; //3

    public final static int[][] TSHAPE_R1={{ 0,-1}, { 0, 0}, { 1, 0}, { 0, 1}}; //4
    public final static int[][] TSHAPE_R2={{-1, 0}, { 0, 0}, { 1, 0}, { 0,-1}};
    public final static int[][] TSHAPE_R3={{ 0,-1}, { 0, 0}, { 0, 1}, {-1, 0}};

    // pas de rotation pour Forme// 5
    public final static int[][]  LSHAPE_R1={{ -1, 0 }, {  0, 0 }, { 1, 0 }, { 1, -1 }}; //6
    public final static int[][]  LSHAPE_R2={{ -1,-1 }, {  0,-1 }, { 0, 0 }, { 0,  1 }};
    public final static int[][]  LSHAPE_R3={{ -1, 1 }, { -1, 0 }, { 0, 0 }, { 1,  0 }};

    public final static int[][] MIROREDLSHAPE_R1={{-1, 0 }, { 0, 0 }, { 1, 0 }, {  1, 1 }}; //7
    public final static int[][] MIROREDLSHAPE_R2={{ 0,-1 }, { 1,-1 }, { 0, 0 }, {  0, 1 }  };
    public final static int[][] MIROREDLSHAPE_R3={{-1,-1 }, {-1, 0 }, { 0, 0 }, {  1 , 0 } };

/* MES FORMES: études des formes et des rotations possibles
 -forme 1: {  0,  1}, { 0,  0 },  { 1, 0 },  { 1, -1 } ZShape
           { -1, -1}, { 0, -1 },  { 0, 0 },  { 1,  0}  R1
 ......    1,-1 .....  -1,-1  0,-1
 ......0,0 1,0  =RG1>         0, 0  1,0
 ......0,1      .....

- forme 2:   { 0, 0 }, { 1, 0 },  { -1, 1 }, { 0, 1} SShape
             { 0,-1 }, { 0, 0 },  {  1, 0 }, { 1, 1} R1

 ......                 .....    0,-1
 ......      0,0 1,0    =>RG1    0, 0  1,0
 ...... -1,1 0,1        .....          1,1

 -forme 3: { -1, 0}, { 0, 0 }, { 1, 0 },  { 2, 0 } LineShape
           {  0, 1}  { 0, 0 }, { 0, -1 }, { 0, -2} R1
                        ..... 0,1
 ......-1,0 0,0 1,0 2,0 =>RG1 0,0  =RG2> forme 3
                        ..... 0,-1
                        ..... 0,-2

- forme 4: { -1 , 0 }, { 0 , 0 }, { 1 , 0 }, { 0 , 1 }  TShape
           {  0 ,-1 }, { 0 , 0 }, { 1 , 0 }, { 0 , 1 }  RG1
           { -1 , 0 }, { 0 , 0 }, { 1 , 0 }, { 0 , -1 } RG2
           {   0, -1}, { 0 , 0 }, { 0 , 1 }, {-1 , 0 }  RG3

.....                 .....  0,-1      .....       0,-1      .....       0,-1
..... -1,0  0,0  1,0  =>RG1  0,0  1,0  =>RG2 -1,0  0,0  1,0  =>RG3 -1,0  0,0
.....       0,1       .....  0,1       .....                 .....       0,1

 - forme 5:   { 0, 0 },   { 1, 0 },  { 0, 1 },{ 1, 1} SquareShape
 ......  0,0 1,0     =>NO RG
 ......  0,1 1,1

  -forme 6: {  0,-1 }, {  0, 0 }, { 0, 1 }, { 1,  1 } LShape
            { -1, 0 }, {  0, 0 }, { 1, 0 }, { 1, -1 } RG1
            { -1,-1 }, {  0,-1 }, { 0, 0 }, { 0,  1 } RG2
            { -1, 1 }, { -1, 0 }, { 0, 0 }, { 1,  0 } RG3

 ......0,-1      .....             1,-1   ..... -1,-1  0,-1  .....
 ......0,0       =>RG1  -1,0  0,0  1,0    =>RG2        0, 0  =>RG3  -1,0  0,0 1,0
 ......0,1 1,1   .....                    .....        0, 1  .....  -1,1


 -forme 7: { 0,-1 }, { 0, 0 }, { 0, 1 }, { -1, 1 } MiroredLShape
           {-1, 0 }, { 0, 0 }, { 1, 0 }, {  1, 1 } RG1
           { 0,-1 }, { 1,-1 }, { 0, 0 }, {  0, 1 }  RG2
           {-1,-1 }, {-1, 0 }, { 0, 0 }, {  1 , 0 } RG3

 ......     0,-1  .....                 ..... 0,-1 1,-1   .....  -1,-1
 ......     0,0   =>RG1  -1,0  0,0 1,0  =>RG2 0,0         =>RG3  -1,0  0,0  1,0
 ......-1,1 0,1   .....            1,1  ..... 0,1         .....


======================================AUTRES FORMES
 -forme 2: { 0, -1},  { 0,  0 },  { 1, 0 },  { 1, 1 } MiroredZShape
           { -1, 0},  { 0, -1 },  { 0, 0 },  { 1, -1} R1
 ......0,-1     .....       0,-1 1,-1
 ......0,0 1,0  =>RG1> -1,0 0,0
 ......    1,1  .....

 -forme 4:   { -1, 0 },   { 0, 0 },  { 0, 1 }, { 1, 1} MiroredSShape
             {  1,-1 },   { 1, 0 },  { 0, 0 }, { 0,1}  R1
 ......                   .....            1,-1
 ......-1,0 0,0            =>RG1      0,0  1,0
 ......     0,1 1,1        .....      0,1

 */
    public final static Color[] TABLEAU_DES_COULEURS
            = {new Color(0, 0, 0),
            new Color(204, 102, 102),
            new Color(102, 204, 102), // ZShape
            new Color(102, 102, 204), // SShape
            new Color(204, 204, 102), // LineShape
            new Color(204, 102, 204), // TSHape
            new Color(102, 204, 204), // LShape
            new Color(218, 170, 0) ,
            new Color(233, 126, 0), // NEW1: forme pour essai et tests
            new Color(233, 152, 63) // NEW1RG forme2 pour essai et tests
    };

    public static final int MAX_POINT = 4; //4 points
    public static final int MAX_COORD = 2 ; // les coordonnées
    public static final int IDX_X =0 ;
    public static final int IDX_Y =1;


    public static String MENU_NOM="LeJeu";

    public static String MENU_ITEM_DEMARRER="Démarrer";
    public static String MENU_ITEM_PAUSER="Mettre en pause";
    public static String MENU_ITEM_DEPAUSER="ôter la pause";
    public static String MENU_ITEM_QUITTER="Quitter";
    public static String[] MENU_ITEMS={MENU_ITEM_DEMARRER,MENU_ITEM_PAUSER,MENU_ITEM_QUITTER};

    public static int[] MENU_ITEMS_VK={KeyEvent.VK_D,KeyEvent.VK_P,KeyEvent.VK_Q};


    private ConstantesIhm(){}
}
