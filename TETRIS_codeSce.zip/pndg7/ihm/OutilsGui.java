package pndg7.ihm;

import pndg7.model.Ensemble;
import pndg7.model.FabriqueMetier;
import pndg7.model.ShapeCurrent;
import pndg7.model.Tetrominoe;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

public final class OutilsGui {
    private OutilsGui() {   }

    public static int squareWidth( int w ) {
        return (int) w / ConstantesIhm.BOARD_WIDTH;
    }

    public static int squareHeight( int h ) {
        return (int) h / ConstantesIhm.BOARD_HEIGHT;
    }

    public static void drawSquare( Graphics g, JPanel jpan, int x, int y, Tetrominoe shape ) {

        int w = jpan.getWidth();
        int h = jpan.getHeight();

        Color color = getColor(shape); //MEP couleur pour une forme

        g.setColor(color);
        g.fillRect(x + 1, y + 1, squareWidth(w) - 2, squareHeight(h) - 2);

        g.setColor(color.brighter());
        g.drawLine(x, y + squareHeight(h) - 1, x, y);
        g.drawLine(x, y, x + squareWidth(w) - 1, y);

        g.setColor(color.darker());
        g.drawLine(x + 1, y + squareHeight(h) - 1,
                x + squareWidth(w) - 1, y + squareHeight(h) - 1);
        g.drawLine(x + squareWidth(w) - 1, y + squareHeight(h) - 1,
                x + squareWidth(w) - 1, y + 1);
    }

    public static int removeFullLines( Ensemble lesPieces, ShapeCurrent curPiece ) {
        int numFullLines = 0;
        boolean lineIsFull = true;
        for (int i = ConstantesIhm.BOARD_HEIGHT - 1; i >= 0; i--) {
            lineIsFull = true;
            for (int j = 0; j < ConstantesIhm.BOARD_WIDTH; j++) {
                if (lesPieces.getFormeAt(j, i) == Tetrominoe.NoShape) {
                    lineIsFull = false;
                    break;
                }
            }

            if (lineIsFull) {
                numFullLines++;
                for (int k = i; k < ConstantesIhm.BOARD_HEIGHT - 1; k++) {
                    for (int j = 0; j < ConstantesIhm.BOARD_WIDTH; j++) {
                        // lesPieces[(k * ConstantesIhm.BOARD_WIDTH) + j] = shapeAt(j, k + 1);
                        lesPieces.setFormeAt(j, k, lesPieces.getFormeAt(j, k + 1));
                    }
                }
                //System.out.println(" nb ligne pleine="+numFullLines);
            }
        }

        //MAJ curPiece
        curPiece.setFallingFinished(true);
        curPiece.setForme(Tetrominoe.NoShape);

        return numFullLines;
    }

    public static int pieceDropped( ShapeCurrent curPiece, Ensemble lesPieces ) {
        for (int i = 0; i < 4; i++) {
            int x = curPiece.getPtCourant().x + curPiece.x(i);
            int y = curPiece.getPtCourant().y - curPiece.y(i);

            lesPieces.setFormeAt(x, y, curPiece.getForme());
        }
        int nbFullLine = removeFullLines(lesPieces, curPiece);
        if (!curPiece.isFallingFinished()) {
            int minY = minY(curPiece);
            //newPiece(curPiece);
            curPiece = newPiece(minY);
        }

        return nbFullLine;
    }

    /**
     * Recherch du minimum pour les Y.
     *
     * @param current: ShapeCurrent
     * @return int
     */
    public static int minY( ShapeCurrent current ) {
        int m = current.getCoords()[0][ConstantesIhm.IDX_Y];
        for (int i = 0; i < 4; i++) {
            m = Math.min(m, current.getCoords()[i][ConstantesIhm.IDX_Y]);//y=1
        }
        return m;
    }
    public static int maxX( ShapeCurrent current ) {
        int m = current.getCoords()[0][ConstantesIhm.IDX_X];
        for (int i = 0; i < 4; i++) {
            m = Math.max(m, current.getCoords()[i][ConstantesIhm.IDX_X]);//x=0
        }
        return m;
    }
    public static int minX( ShapeCurrent current ) {
        int m = current.getCoords()[0][ConstantesIhm.IDX_X];
        for (int i = 0; i < 4; i++) {
            m = Math.min(m, current.getCoords()[i][ConstantesIhm.IDX_X]);
        }
        return m;
    }

    /**
     * Méthode chargée de générer une nouvelle pièce courante.
     *
     * @param minY: int
     * @return ShapeCurrent
     */
    public static ShapeCurrent newPiece( int minY ) {

        ShapeCurrent newCurPiece = FabriqueMetier.creerShapeCurrent();

        Tetrominoe newTetro = generateRandomShape(); //Tirage nouvelle forme
        newCurPiece.setForme(newTetro); // mep forme
        newCurPiece.setCoords(getCoords(newTetro)); //mep des coordonnées pour une forme

        Point pt = new Point(ConstantesIhm.BOARD_WIDTH / 2 + 1, ConstantesIhm.BOARD_HEIGHT - 2 + minY);
        newCurPiece.setPtCourant(pt);

        return newCurPiece;
    }

    public static int[][] getCoords( Tetrominoe t ) {
        return ConstantesIhm.TABLEAU_COORDS_FORMES[t.ordinal()];
    }

    public static Color getColor( Tetrominoe t ) {
        return ConstantesIhm.TABLEAU_DES_COULEURS[t.ordinal()];
    }

    /**
     * Méthode chargée de tirer une forme au hasard parmi toutes les valeurs de l'Enum Tetrominoe.
     *
     * @return Tetrominoe
     */
    private static Tetrominoe generateRandomShape() {
        var r = new Random();
        int x = Math.abs(r.nextInt()) % 7 + 1;
        Tetrominoe[] values = Tetrominoe.values();
        //System.out.println(String.format("%n %02d %s",x,values[x].name()));
        return values[x];
    }

    private static boolean isInside( ShapeCurrent sc, int y, int x ) {
       // System.out.println(sc);
        int maxX=maxX(sc);
        int minX=minX(sc);
        boolean outx = (maxX<0 || maxX> ConstantesIhm.BOARD_WIDTH-1) || (x < 0 || x > ConstantesIhm.BOARD_WIDTH - 1);
        boolean outy=(y < 0 || y > ConstantesIhm.BOARD_HEIGHT);
        //System.out.println(String.format("isInside() [y=%02d(22):x=%02d(15)] %B", y, x,!out));
        return !(outx||outy);
    }

    /**
     * Méthode chargée de renvoyer si le déplacement/placement de la Pièce courante est possible.
     *
     * @param laPiece: ShapeCurrent
     * @param depX:    int, le déplacement pour abscisses
     * @param depY:    int, le déplacement pour les ordonnées
     * @return boolean VRAI si c'est possible, sinon FAUX
     */
    public static boolean tryMove( ShapeCurrent laPiece, int depX, int depY, Ensemble lesPieces ) {

        int newX = laPiece.getPtCourant().x + depX;
        int newY = laPiece.getPtCourant().y + depY;

        if (newX < 0 && newY < 0) {
            return false;
        }
        // les coordonnées sont >=0
        int i = 0;
        do {
            int x = newX + laPiece.x(i);
            int y = newY - laPiece.y(i);

            //if (x < 0 || x > ConstantesIhm.BOARD_WIDTH || y < 0 || y > ConstantesIhm.BOARD_HEIGHT) {
            if (!isInside(laPiece, y, x)) {
                //System.out.println(">>hors de la fenêtre");
                return false;
            } else {
                if (lesPieces.getFormeAt(x, y) != Tetrominoe.NoShape) {
                    return false;
                }
            }
            //incrémentation
            i++;
        } while (i < 4);

        return true;
    }

    /**
     * Méthode chargée de placer la piece courante avec les déplacements en x et y.
     *
     * @param sc: shapeCurrent
     * @param dy: int le déplacement sur l'axe des x
     * @param dx: int le déplacement sur l'axe des y
     */
    public static void move( ShapeCurrent sc, int dx, int dy ) {
        int nx = sc.getPtCourant().x + dx;
        int ny = sc.getPtCourant().y + dy;

        Point newPt = new Point(nx, ny);
        sc.setPtCourant(newPt);
    }

    /**
     * Méthode chargée de renvoyer les coordonnées après une rotation.
     *
     * @param tetro:      Tetrominoe, la forme
     * @param noRotation: int , le compteur de rotation
     * @return int[][]
     */
    public static int[][] calculerRotation( Tetrominoe tetro, int noRotation ) {
        int[][] tabloRotation = null;
        int idxTetro = tetro.ordinal();

        switch (noRotation) {
            case 0:
                tabloRotation = OutilsGui.getCoords(tetro);
                break;
            case 1:
                switch (idxTetro) {
                    case 1:
                        tabloRotation = ConstantesIhm.ZSHAPE_R1;
                        break;
                    case 2:
                        tabloRotation = ConstantesIhm.SSHAPE_R1;
                        break;
                    case 3:
                        tabloRotation = ConstantesIhm.LINESHAPE_R1;
                        break;
                    case 4:
                        tabloRotation = ConstantesIhm.TSHAPE_R1;
                        break;
                    case 6:
                        tabloRotation = ConstantesIhm.LSHAPE_R1;
                        break;
                    case 7:
                        tabloRotation = ConstantesIhm.MIROREDLSHAPE_R1;
                        break;
                }
                break;
            case 2:
                switch (idxTetro) {
                    case 4:
                        tabloRotation = ConstantesIhm.TSHAPE_R2;
                        break;
                    case 6:
                        tabloRotation = ConstantesIhm.LSHAPE_R2;
                        break;
                    case 7:
                        tabloRotation = ConstantesIhm.MIROREDLSHAPE_R2;
                        break;
                }

                break;
            case 3:
                switch (idxTetro) {
                    case 4:
                        tabloRotation = ConstantesIhm.TSHAPE_R3;
                        break;
                    case 6:
                        tabloRotation = ConstantesIhm.LSHAPE_R3;
                        break;
                    case 7:
                        tabloRotation = ConstantesIhm.MIROREDLSHAPE_R3;
                        break;
                }
                break;
        }

        return tabloRotation;

    }

    // --------------OUTILS AFFICHAGE
    public static void afficherTabCoords( int[][] t ) {
        StringBuffer sb = new StringBuffer("\n--Coordonnées");
        for (int i = 0; i < t.length; i++) {
            sb.append("\n carré nO:" + (i + 1) + " !! ");
            for (int y = 0; y < t[i].length; y++) {
                int c = t[i][y];
                sb.append((c >= 0 ? " " : "") + c + " ! ");
            }
        }
        System.out.println(sb.toString());
    }
}
