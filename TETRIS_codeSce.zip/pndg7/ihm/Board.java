package pndg7.ihm;

import pndg7.model.*;
import pndg7.presenter.Presenter;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Objects;

public class Board extends JPanel {

    private Timer timer;
    private JLabel statusbar;
    private ShapeCurrent curPiece; //La pièce en train de tomber

    private int numLinesRemoved = 0;
    private Presenter pres;


    public Board( FenetreTetris parent, Presenter p) {
        this.pres = p;
        initBoard(parent);
    }

    private void initBoard( FenetreTetris parent ) {

        setFocusable(true);
        statusbar = parent.getStatusBar();
        addKeyListener(new TAdapter());
    }

    void start() {
        if(pres.getFacadeJeu().getEtatDuJeu()== TypeEtatsDuJeu.DEMARRE) {
            curPiece = FabriqueMetier.creerShapeCurrent();

            //lesPieces = new Ensemble(ConstantesIhm.BOARD_WIDTH * ConstantesIhm.BOARD_HEIGHT);
            pres.getFacadeJeu().clearLesPieces();

            newPiece();
            timer = new Timer(ConstantesIhm.PERIOD_INTERVAL, new GameCycle());
            timer.start();
        }
    }

    public void pauserLeJeu() {
        pres.getFacadeJeu().mettreLeJeuEnPause();

        //System.out.println("-leBoard.pause(), JEU.etat="+leJeu.getEtat().name());

        if (pres.getFacadeJeu().getEtatDuJeu() == TypeEtatsDuJeu.PAUSE) {
            statusbar.setText("paused");
        } else {
            statusbar.setText(String.valueOf(numLinesRemoved));
        }
        repaint();
    }

    @Override
    public void paintComponent( Graphics g ) {
        super.paintComponent(g);
        doDrawing(g);
    }

    private void doDrawing( Graphics g )  {
        if(pres.getFacadeJeu().getEtatDuJeu() == TypeEtatsDuJeu.DEMARRE || pres.getFacadeJeu().getEtatDuJeu()  == TypeEtatsDuJeu.PAUSE) {
            int h = this.getHeight();
            int w = this.getWidth();

            var size = getSize();
            int boardTop = (int) size.getHeight() - ConstantesIhm.BOARD_HEIGHT * OutilsGui.squareHeight(h);

            for (int i = 0; i < ConstantesIhm.BOARD_HEIGHT; i++) {
                for (int j = 0; j < ConstantesIhm.BOARD_WIDTH; j++) {

                    Tetrominoe shape = pres.getFacadeJeu().getFormeAt(j, ConstantesIhm.BOARD_HEIGHT - i - 1);
                    if (Objects.nonNull(shape) && shape != Tetrominoe.NoShape) {
                        OutilsGui.drawSquare(g, this, j * OutilsGui.squareWidth(w),
                                boardTop + i * OutilsGui.squareHeight(h), shape);
                    }
                }
            }

            if (curPiece.getForme() != Tetrominoe.NoShape) {
                for (int i = 0; i < 4; i++) {
                    Point curCoords = curPiece.getPtCourant();
                    int x = curCoords.x + curPiece.x(i);
                    int y = curCoords.y - curPiece.y(i);

                    //System.out.println(String.format(" [y=%02d, x=%02d] %S",y,x,curPiece.getForme().name()));

                    OutilsGui.drawSquare(g, this, x * OutilsGui.squareWidth(w),
                            boardTop + (ConstantesIhm.BOARD_HEIGHT - y - 1) * OutilsGui.squareHeight(h),
                            curPiece.getForme());
                }
            }
        }
    }

    private void dropDown()  {
        int newY = curPiece.getPtCourant().y;

        while (newY > 0) {
            if (!OutilsGui.tryMove(curPiece, 0, - 1, pres.getFacadeJeu().getLesPieces())) {
                break;
            }
            OutilsGui.move(curPiece,0,-1);
            newY--;
        }

        int nbFullLine = OutilsGui.pieceDropped(curPiece,pres.getFacadeJeu().getLesPieces());
        majDuScore(nbFullLine);
    }

    private void majDuScore( int nbFullLine ) {
        if (nbFullLine > 0) {
            numLinesRemoved += nbFullLine;
            statusbar.setText(String.format(" Score=%03d",numLinesRemoved));
        }
    }

    private void oneLineDown() {
        if (!OutilsGui.tryMove(curPiece, 0, - 1,pres.getFacadeJeu().getLesPieces())) {
                //pieceDropped();
                int nbFullLine = OutilsGui.pieceDropped(curPiece,pres.getFacadeJeu().getLesPieces());
                majDuScore(nbFullLine);
        }
        OutilsGui.move(curPiece,0,-1);
    }

    private void newPiece() {
        curPiece = OutilsGui.newPiece(0); //??
        if (!OutilsGui.tryMove(curPiece, 0, 0,pres.getFacadeJeu().getLesPieces())) {
            curPiece.setForme(Tetrominoe.NoShape);
            timer.stop();

            var msg = String.format("Game over. Score: %d", numLinesRemoved);
            statusbar.setText(msg);
        }
    }

    public void demarrerLeJeu() {
        pres.getFacadeJeu().demarrerLeJeu();
        this.start();
    }

    public void arreterJeu() {
        pres.getFacadeJeu().arreterLeJeu();
        timer.stop();
        System.exit(0);
    }

    public boolean isJeuPaused() {
        return pres.getFacadeJeu().isJeuPaused();
    }

    private class GameCycle implements ActionListener {

        @Override
        public void actionPerformed( ActionEvent e ) {

            doGameCycle();
        }
    }

    private void doGameCycle() {
        update();
        repaint();
    }

    private void update() {
        if (pres.getFacadeJeu().isJeuPaused()) {
            return;
        }

        if (curPiece.isFallingFinished()) {
            curPiece.setFallingFinished(true);
            newPiece();
        } else {
            oneLineDown();
        }
    }

    class TAdapter extends KeyAdapter {

        @Override
        public void keyPressed( KeyEvent e ) {
            if (curPiece.getForme() == Tetrominoe.NoShape) {
                return;
            }

            int keycode = e.getKeyCode();

            switch (keycode) {
                case KeyEvent.VK_P:
                    pauserLeJeu();
                    break;
                case KeyEvent.VK_LEFT:
                    if(OutilsGui.tryMove(curPiece,  - 1, 0,pres.getFacadeJeu().getLesPieces())) {
                        OutilsGui.move(curPiece, -1, 0);
                    }
                    break;
                case KeyEvent.VK_RIGHT:
                    if(OutilsGui.tryMove(curPiece, 1,0,pres.getFacadeJeu().getLesPieces())) {
                        OutilsGui.move(curPiece, 1, 0);
                    }
                    break;
                case KeyEvent.VK_DOWN:
                case KeyEvent.VK_UP:
                    curPiece.rotate();
                    if(OutilsGui.tryMove(curPiece, 0, 0,pres.getFacadeJeu().getLesPieces())) {
                        OutilsGui.move(curPiece, 0, 0);
                    }
                    break;
                case KeyEvent.VK_SPACE:
                    dropDown();
                    break;
                case KeyEvent.VK_D:
                    oneLineDown();
                    break;
            }
            repaint();
        }
    }

}
