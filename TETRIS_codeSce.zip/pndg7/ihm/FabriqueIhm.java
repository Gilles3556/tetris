package pndg7.ihm;

import pndg7.model.FacadeJeuTetris;
import pndg7.model.JeuTetris;
import pndg7.presenter.Presenter;

import javax.swing.*;

public final class FabriqueIhm {
    private FabriqueIhm(){}

    public static FenetreTetris creerFenetreTetris( Presenter p){
        return new FenetreTetris(p);
    }

    public static Board creerBoard( FenetreTetris fenT, Presenter p ){
        return new Board(fenT, p);
    }

    public static JMenu creerMenu( FenetreTetris fenT){
        JMenuItem[] lesItems= new JMenuItem[3];

        JMenu leMenu = new JMenu(ConstantesIhm.MENU_NOM);
        for(int m = 0; m< ConstantesIhm.MENU_ITEMS.length; m++) {
            lesItems[m] = new JMenuItem(ConstantesIhm.MENU_ITEMS[m], ConstantesIhm.MENU_ITEMS_VK[m]);

            //MEP des JmenuItem et Ecouteur d'action
            lesItems[m].addActionListener(fenT);
            leMenu.add(lesItems[m]);
        }
        return leMenu;
    }
    public static JMenuBar creerBarreDeMenu( FenetreTetris fenT){
        JMenuBar barreDeMenu = new JMenuBar();

        barreDeMenu.add(FabriqueIhm.creerMenu(fenT));

        return barreDeMenu;
    }

}
