package pndg7.start;

import pndg7.model.FabriqueMetier;
import pndg7.presenter.Presenter;

public class Lanceur7 {
    public static void main(String[] args) {

        var ens = FabriqueMetier.creerEnsemble();

        Presenter pres = new Presenter(ens);
        pres.start();
    }
}
